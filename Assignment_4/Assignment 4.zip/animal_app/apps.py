from django.apps import AppConfig


class AnimalAppConfig(AppConfig):
    name = 'animal_app'
