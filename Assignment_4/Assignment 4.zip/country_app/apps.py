from django.apps import AppConfig


class CountryAppConfig(AppConfig):
    name = 'country_app'
