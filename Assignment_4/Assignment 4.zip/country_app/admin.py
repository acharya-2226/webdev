from django.contrib import admin
from .models import Country

admin.site.register(Country)

