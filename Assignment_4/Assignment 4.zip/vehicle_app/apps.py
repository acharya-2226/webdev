from django.apps import AppConfig


class VehicleAppConfig(AppConfig):
    name = 'vehicle_app'
